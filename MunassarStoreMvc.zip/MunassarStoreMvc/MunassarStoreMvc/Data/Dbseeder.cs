﻿using Microsoft.AspNetCore.Identity;
using MunassarStoreMvc.Constants;

namespace MunassarStoreMvc.Data
{
    public class Dbseeder
    {
        public static async Task SeedDefaultData(IServiceProvider service)
        {
            var userMger = service.GetService<UserManager<IdentityUser>>();
            var roleMger = service.GetService<RoleManager<IdentityRole>>();

            //kudar xoogahaa xeerar to db
            await roleMger.CreateAsync(new IdentityRole(Roles.Admin.ToString()));
            await roleMger.CreateAsync(new IdentityRole(Roles.User.ToString()));

            //samee admin user 

            var admin = new IdentityUser
            {
                UserName = "admin@gmail.com",
                Email = "admin@gmail.com",
                EmailConfirmed = true
            };

            var UsertInDb = userMger.FindByEmailAsync(admin.Email);
            if (UsertInDb is null) 
            {
                await userMger.CreateAsync(admin, "Munassar.123");
                await userMger.AddToRoleAsync(admin, Roles.Admin.ToString());
            }




        }
    }
}
