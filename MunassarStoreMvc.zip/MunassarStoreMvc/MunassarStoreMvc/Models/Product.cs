﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MunassarStoreMvc.Models
{
    [Table("Product")]
    public class Product
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(40)]
        public string? ProductName { get; set; }
        [Required]
        [MaxLength(40)]
        public string? ManufacturerName { get; set; }
        [Required]
        public double Price { get; set; }
        public string? Image { get; set; }
        [Required]
        public int CategoryId { get; set; }

        public Category Category { get; set; }

        public List<OrderDeatail> OrderDeatail{ get; set; }
        public List<CartDeatil> CartDeatil { get; set; }

        [NotMapped]
        public string CategoryName { get; set; } 

    }
}
