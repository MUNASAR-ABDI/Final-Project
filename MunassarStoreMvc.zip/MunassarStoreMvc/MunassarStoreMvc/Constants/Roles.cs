﻿namespace MunassarStoreMvc.Constants
{
   public enum Roles
    {
        User =1,
        Admin
    }
}
