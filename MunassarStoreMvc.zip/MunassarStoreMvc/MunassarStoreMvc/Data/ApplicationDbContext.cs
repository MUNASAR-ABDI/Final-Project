﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MunassarStoreMvc.Models;

namespace MunassarStoreMvc.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ShoppingCart> ShoppingCarts { get; set; }
        public DbSet<CartDeatil> CartDeatils { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDeatail> OrderDeatails { get; set; }
        public DbSet<OrderTrack> OrderTracks { get; set; }
    }
}
