﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations.Schema;

namespace MunassarStoreMvc.Models
{
    [Table("Order")]
    public class Order
    {
        public int Id { get; set; }
        [Required]
        public string? UserId { get; set; }
        [Required]
        public DateTime CreateDate { get; set; } = DateTime.UtcNow;
        [Required]
        public int OrderTrackId {  get; set; }

        public bool IsDeleted { get; set; } = false;

        public OrderTrack OrderTrack {  get; set; }

        public List<OrderDeatail> orderDeatail { get; set; }

    }
}
