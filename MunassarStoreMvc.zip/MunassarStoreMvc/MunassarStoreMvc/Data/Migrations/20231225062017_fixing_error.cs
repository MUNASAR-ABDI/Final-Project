﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MunassarStoreMvc.Data.Migrations
{
    /// <inheritdoc />
    public partial class yyy : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "UnitPrice",
                table: "CartDeatil",
                type: "float",
                nullable: false,
                defaultValue: 0.0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UnitPrice",
                table: "CartDeatil");
        }
    }
}
