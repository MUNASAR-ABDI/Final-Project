﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MunassarStoreMvc.Models
{
    [Table("OrderTrack")]
    public class OrderTrack
    {
        public int Id { get; set; }
        [Required]
        public int TrackId { get; set; }
        [Required]
        [MaxLength(30)]
        public string? TrackName { get; set; }
    }
}
