﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MunassarStoreMvc.Data.Migrations
{
    /// <inheritdoc />
    public partial class addedcodeinorder : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "OrderTrack",
                table: "Order");

            migrationBuilder.CreateIndex(
                name: "IX_Order_OrderTrackId",
                table: "Order",
                column: "OrderTrackId");

            migrationBuilder.AddForeignKey(
                name: "FK_Order_OrderTrack_OrderTrackId",
                table: "Order",
                column: "OrderTrackId",
                principalTable: "OrderTrack",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Order_OrderTrack_OrderTrackId",
                table: "Order");

            migrationBuilder.DropIndex(
                name: "IX_Order_OrderTrackId",
                table: "Order");

            migrationBuilder.AddColumn<int>(
                name: "OrderTrack",
                table: "Order",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
