﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MunassarStoreMvc.Controllers
{
    [Authorize]
    public class OrderController : Controller
    {
        private readonly IUserOrderRepository _userOrderRepo;

        public OrderController(IUserOrderRepository userOrderRepo)
        {
            _userOrderRepo = userOrderRepo;
        }
        public async Task<IActionResult> UserOrders()
        {
            var orders =await _userOrderRepo.UserOrders();
            return View(orders);
        }
    }
}
